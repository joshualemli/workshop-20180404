
// create an object to map list-item "id" to a description sentence


// create a function that puts text into the description element


// create a variable that points to all the list items
// NOTE: we must wait for the page to load in order to do this!


    // loop through each item and add an event listener to display the details

