

// variables

var x = 2.5
var name = "dog"

var y = x*3



// constants

const DOG = "good"



// arrays

var arrOfIntegers = [1,1,2,3,5,8,13,21]
var arrOfMixed = ["bob", "dog", 5, "dog", 3000000]



// functions

function f(x) {
    return x * 11
}

var F = x => x*11

var getSignChar = x => {
    if (x >= 0) return "+"
    else return "-"
}



// function examples

f(10)
F(55)
getCharSign(-100)

// the console!

console.log(x)
console.log(name)
console.log(x,name,arrOfMixed)
console.log(
    f(10),
    F(55),
    getCharSign(-100)
)


// objects

var DogHouse = {
    dogs: ["Jax","Yammi"],
    maxDogs: 3,
    addDog: function(dog) {
        if (DogHouse.dogs.length < DogHouse.maxDogs) dogs.push(dog)
        else console.log("Dog house is full!")
    }
}

console.log(DogHouse.dogs)
DogHouse.addDog("Rex")



