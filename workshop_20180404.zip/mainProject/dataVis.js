

// Regular Expression for finding newlines or carriage returns
const regExpForRows = /[\n\r]+/g

// Regular Expression for finding tabs or commas
const regExpForCols = /[\t,]/g


// Function to request and parse the data (ASYNC!)


// Wait until data is retrieved (ASYNC!) using `Promise.all`


    // Log the result of the async operations


    // Store the data with some nicely named variables


    // Create an empty set to store "selected" SiteIDs


    // Use `require` to import the following modules:
    // ----------------------------------------------
    //  - esri Map
    //  - esri SceneView
    //  - esri GraphicsLayer
    //  - esri Graphic
    //  - Plotly.js
    //  - dojo domReady



        // Create the map
        // --------------
        // 1) create an esri `SceneView`
        // 2) specify a container element, a starting viewpoint, and an esri `Map`



        // Add a "graphics layer" to contain the sites
        // -------------------------------------------
        // 1) create the esri `GraphicsLayer`
        // 2) add it to the map



        // Add sites to the map
        // --------------------
        // 1) loop through the rows of site data
        // 2) create an "esri Graphic" for each site
        //     - geometry
        //     - attributes
        //     - symbol
        // 3) add graphic to the graphics layer



        // Add onclick behavior to the map
        // -------------------------------
        // 1) add a listener for "click" on the view
        // 2) perform a `hitTest` on the view
        // 3) check if any results were found
        // 4) if results found, add or remove the SiteID from the selection set
        // 5) replot the data for those sites (use a function!)
        // BONUS: change the graphic to represent if it's being plotted or not!




        // Get the plot container


        // Create a function to plot all data for selected sites
        // -----------------------------------------------------
        // 1) create a placeholder for any series we will plot
        // 2) loop through selected SiteIDs
        // 3) filter data based on each SiteID
        // 4) add the resulting subset to the series we want to plot
        // 5) redraw the plot




