
// map list-item "id" to a description sentence
var breedDetails = {
    lab: "A friendly and popular breed. Prone to hip-dysplasia.",
    mutt: "The best, the healthiest, the most unique.",
    pit: "A misunderstood breed, pitbulls are among the sweetest and most sociable of all dog breeds.",
    ridgeback: "Fierce, loyal, and brave, these dogs were first bred in Africa to hunt lions.  Yes, really."
}

// puts text into the description element
function setDetailsText(breedName) {
    var detailsElement = document.getElementById("breedDetails")
    var text = breedDetails[ breedName ]
    detailsElement.innerHTML = text
}

// create a variable that points to all the list items
// NOTE: we must wait for the page to load in order to do this!

window.addEventListener("load",function(){
    
    var listItems = document.getElementsByClassName("breed")

    // loop through each item and add an event listener to display the details
    for (var i = 0; i < listItems.length; i++) {
        listItems[i].addEventListener("click",function(event){
            setDetailsText(event.target.id)
        })
    }

})
